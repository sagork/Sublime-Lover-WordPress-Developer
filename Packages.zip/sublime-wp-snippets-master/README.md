sublime-wp-snippets
===================

Snippets with keybindings for WordPress theme developers using sublime text 3

#### How to install:
1. cd Library/Application\ Support/Sublime\ Text\ 3/Packages/User
2. git clone https://github.com/AaronRutley/sublime-wp-snippets/ sublime-wp-snippets
