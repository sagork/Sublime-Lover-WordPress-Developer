# WordPress Offline Help

#### [Sublime Text 2](http://www.sublimetext.com/2)

### Only for Windows/Только для Windows

## About/О плагине
This is a Sublime Text 2 plugin for search WordPress functions in CHM(Microsoft Compiled HTML Help).  
Right-click on any WordPress function and select 'Open WordPress Help' to open CHM help for this function.  
CHM generated with [Doxygen](http://www.doxygen.org/) from WordPress version 3.2 sources.

Это Sublime Text 2 плагин предназначенный для поиска WordPress функций в CHM справке.  
Просто установите курсор на нужной функции, нажмите правую кнопку мышки и выберите команду 'Open WordPress Help'.  
CHM сгенерирован с помощью [Doxygen](http://www.doxygen.org/) из исходных кодов WordPress версии 3.2.

## Usage/Использование
Right click on any function and select 'Open WordPress Help', or press Ctrl+Alt+z  
Установите курсор на нужной функции, нажмите правую кнопку мышки и выберите команду 'Open WordPress Help', или нажмите комбинацию клавиш
Ctrl+Alt+z

## Install/Установка

Download and unpack to your Sublime Text 2 package folder(Preferences->Browse Packages)  
Загрузите и распакуйте в папку с Sublime Text 2 плагинами(Preferences->Browse Packages)