import sublime, sublime_plugin, subprocess, os.path

BASE_PATH = os.path.abspath(os.path.dirname(__file__))

def OpenWPHelp(text):
    full_path = os.path.join(BASE_PATH,"keyhh.exe") +  " -#klink " + text + " " + os.path.join(BASE_PATH,"wphelp.chm")
    subprocess.Popen(full_path)



class OpenWordPressHelpCommand(sublime_plugin.TextCommand):
    def run(self, edit):
        sels = self.view.sel()
        for sel in sels:
            if sel.empty():
                sel = self.view.word(sel)

            word = self.view.substr(sel)
            OpenWPHelp(word)